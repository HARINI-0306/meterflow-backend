package com.meterflow.meterflow.repository;

import com.meterflow.meterflow.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {}
