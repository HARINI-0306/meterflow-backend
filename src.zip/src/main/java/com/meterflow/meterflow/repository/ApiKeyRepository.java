package com.meterflow.meterflow.repository;

import com.meterflow.meterflow.model.ApiKey;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApiKeyRepository extends JpaRepository<ApiKey, Long> {
    ApiKey findByApiKey(String apiKey);
}
