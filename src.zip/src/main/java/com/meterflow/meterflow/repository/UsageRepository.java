package com.meterflow.meterflow.repository;

import com.meterflow.meterflow.model.UsageLog;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsageRepository extends JpaRepository<UsageLog, Long> {
    long countByApiKey(String apiKey);
}
