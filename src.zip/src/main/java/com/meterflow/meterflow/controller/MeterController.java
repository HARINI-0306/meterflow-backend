package com.meterflow.meterflow.controller;

import com.meterflow.meterflow.model.*;
import com.meterflow.meterflow.service.MeterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class MeterController {

    @Autowired
    private MeterService service;

    @PostMapping("/user")
    public User createUser(@RequestBody User user) {
        return service.createUser(user);
    }

    @PostMapping("/key/{userId}")
    public ApiKey generateKey(@PathVariable Long userId) {
        return service.generateKey(userId);
    }

    @GetMapping("/use")
    public String useApi(@RequestParam String key,
                         @RequestParam String endpoint) {
        return service.useApi(key, endpoint);
    }

    @GetMapping("/billing")
    public String billing(@RequestParam String key) {
        return service.getBilling(key);
    }
}
