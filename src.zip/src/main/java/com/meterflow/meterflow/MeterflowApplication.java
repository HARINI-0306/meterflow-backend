package com.meterflow.meterflow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeterflowApplication {

	public static void main(String[] args) {
		SpringApplication.run(MeterflowApplication.class, args);
	}

}
