package com.meterflow.meterflow.model;

public class User {

}
