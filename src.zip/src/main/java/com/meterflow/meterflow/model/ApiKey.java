package com.meterflow.meterflow.model;

import jakarta.persistence.*;

@Entity
public class ApiKey {

    @Id
    @GeneratedValue
    private Long id;

    private String apiKey;
    private Long userId;

    public Long getId() { return id; }
    public String getApiKey() { return apiKey; }
    public Long getUserId() { return userId; }

    public void setId(Long id) { this.id = id; }
    public void setApiKey(String apiKey) { this.apiKey = apiKey; }
    public void setUserId(Long userId) { this.userId = userId; }
}
