package com.meterflow.meterflow.model;

import jakarta.persistence.*;

@Entity
public class UsageLog {

    @Id
    @GeneratedValue
    private Long id;

    private String apiKey;
    private String endpoint;
    private long timestamp;

    public Long getId() { return id; }
    public String getApiKey() { return apiKey; }
    public String getEndpoint() { return endpoint; }
    public long getTimestamp() { return timestamp; }

    public void setId(Long id) { this.id = id; }
    public void setApiKey(String apiKey) { this.apiKey = apiKey; }
    public void setEndpoint(String endpoint) { this.endpoint = endpoint; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
}
