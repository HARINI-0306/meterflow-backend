package com.meterflow.meterflow.service;

import com.meterflow.meterflow.model.*;
import com.meterflow.meterflow.repository.*;
import com.meterflow.meterflow.util.ApiKeyGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MeterService {

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private ApiKeyRepository apiRepo;

    @Autowired
    private UsageRepository usageRepo;

    public User createUser(User user) {
        return userRepo.save(user);
    }

    public ApiKey generateKey(Long userId) {
        ApiKey key = new ApiKey();
        key.setUserId(userId);
        key.setApiKey(ApiKeyGenerator.generate());
        return apiRepo.save(key);
    }

    public String useApi(String apiKey, String endpoint) {
        ApiKey key = apiRepo.findByApiKey(apiKey);
        if (key == null) return "Invalid API Key";

        UsageLog log = new UsageLog();
        log.setApiKey(apiKey);
        log.setEndpoint(endpoint);
        log.setTimestamp(System.currentTimeMillis());
        usageRepo.save(log);

        return "API Called Successfully";
    }

    public String getBilling(String apiKey) {
        long count = usageRepo.countByApiKey(apiKey);

        if (count <= 1000) return "Free Plan";

        double bill = (count - 1000) * 0.005;
        return "Requests: " + count + " | Bill: ₹" + bill;
    }
}
